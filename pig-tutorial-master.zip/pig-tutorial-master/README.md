This repository contains the data files for Apache Pig Tutorial hosted on www.rohitmenon.com.


Link to Apache Pig Tutorial - Part 1 - http://www.rohitmenon.com/index.php/apache-pig-tutorial-part-1/


Link to Apache Pig Tutorial - Part 2 - http://www.rohitmenon.com/index.php/apache-pig-tutorial-part-2/
